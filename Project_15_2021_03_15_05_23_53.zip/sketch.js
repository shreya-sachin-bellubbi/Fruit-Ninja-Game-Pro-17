  //Variables for elements of the game
var knife_img;
var fruit1,fruit2,fruit3,fruit4;
var fruit1_img,fruit2_img,fruit3_img,fruit4_img;
var background_img;
var monster;
var monster_img;
var fruitGroup,enemyGroup;
var gameOver_img;

//Variables for storing the sounds
var knifeSwooshSound;
var gameOverSound;

  //Variables for Game State
var PLAY =1;
var END =0;
var gameState=1;

function preload(){
  
  //Loading the images
  knife_img = loadImage("sword.png") 
  fruit1_img =loadImage("fruit1.png");
  fruit2_img =loadImage("fruit2.png");
  fruit3_img =loadImage("fruit3.png");
  fruit4_img =loadImage("fruit4.png");
  monster =loadImage("alien1.png");
  monster_img =loadImage("alien2.png");
  gameOver_img =loadImage("gameover.png");
  
  //Loading the sounds
  knifeSwooshSound = loadSound("knifeSwooshSound.mp3");
  gameOverSound = loadSound("gameover.mp3");
}

function setup(){
  createCanvas(600,600);
  
  
  //Creating the knife
  knife = createSprite(40,200,20,20);
  knife.addImage(knife_img);
  knife.scale=0.7;
  
  //Set collider radius for the knife
  knife.setCollider("rectangle",0,0,40,40);
  
  //Variables for score and the groups
  score=0;
  fruitGroup = createGroup();
  enemyGroup = createGroup();
  
}

function draw(){

  background("lightblue");
  
if(gameState===PLAY){
   
  //Calling the fruit and enemy function
  fruits();
  Enemy();
  
  //Move the knife along with the mouse
  knife.y = World.mouseY;
  knife.x = World.mouseX;
  
  //Destroying the fruits when the knife touches it and adding the score
  if(fruitGroup.isTouching(knife)){
    fruitGroup.destroyEach();
    //Adding sound when the knife touches the fruit
    knifeSwooshSound.play();
    score=score+2;
  }  
  
  //Displaying Game Over when the knife touches the microbes/monster
  if(knife.isTouching(enemyGroup)){
  gameState=END;
  //Adding sound when the game is over
  gameOverSound.play();
  
  }
}

  if(gameState===END){
    fruitGroup.destroyEach();
    enemyGroup.destroyEach();
    fruitGroup.setVelocityXEach(0);
    enemyGroup.setVelocityXEach(0);
    
    //Changing the animation of the knife to the game over image and re-positioning it to the centre of the canvas
    knife.addImage(gameOver_img);
    knife.x=200;
    knife.y=200;
  }
  
  drawSprites();
  
  text("Score:"+score,530,85);
}

  //Creating function for the fruits
function fruits(){
if(World.frameCount%80===0){
  fruit = createSprite (400,200,20,20);
  fruit.scale=0.2
  
  //Making the fruits appear randomly
  r=Math.round(random(1,4));
if (r===1){
  fruit.addImage(fruit1_img);
} else if (r===2){
  fruit.addImage(fruit2_img);
} else if (r===3){
  fruit.addImage(fruit3_img);
}else {
  fruit.addImage(fruit4_img)
} 
  //Fixed Y position for the fruits
  fruit.y=Math.round(random(50,340));
  
  //Defining positions for the fruits for incresing its velocity as game     progresses
  position = Math.round(random(1,2));
  if(position==1){
    fruit.x=400
    fruit.velocityX=-(7+(score/4))
  }
  else{
    if(position==2){
    fruit.x=0;
      
  //Increase the velocity of fruit after score  4 or 10
      fruit.velocityX = (7+(score/4));
    }
  }
  
  //Setting a lifetime for the fruits
  fruit.setLifetime= 150
  
  fruitGroup.add(fruit);
}   
}

  //Creating function for microbes/enemy 
function Enemy(){
if(World.frameCount%200===0){
  monster = createSprite(4000,200,20,20);
  monster.addAnimation("moving",monster_img);
  monster.y = Math.round(random(100,300));
  
  //Increasing the velocity of the microbes as score becomes 10
  monster.velocityX = -(8+(score/10));
    
  //Giving a lifetime to the monsters/microbes
  monster.setLifetime = 50;
    
    enemyGroup.add(monster);
    
  }
}